from resources.lib.externals.hachoir.hachoir_parser.container.asn1 import ASN1File
from resources.lib.externals.hachoir.hachoir_parser.container.mkv import MkvFile
from resources.lib.externals.hachoir.hachoir_parser.container.ogg import OggFile, OggStream
from resources.lib.externals.hachoir.hachoir_parser.container.riff import RiffFile
from resources.lib.externals.hachoir.hachoir_parser.container.swf import SwfFile
from resources.lib.externals.hachoir.hachoir_parser.container.realmedia import RealMediaFile

