# -*- coding: UTF-8 -*-
#######################################################################
# ----------------------------------------------------------------------------
# "THE BEER-WARE LICENSE" (Revision 42):
# Welcome to House Atreides.  As long as you retain this notice you can do whatever you want with this
# stuff. Just please ask before copying. If we meet some day, and you think
# this stuff is worth it, you can buy me a beer in return. - Muad'Dib
# ----------------------------------------------------------------------------
#######################################################################

# Addon Name: Fuck Indgo
# Addon id: plugin.fuck.indigo
# Addon Provider: House Atreides

import shutil

import xbmcgui

xbmcgui.Dialog().ok('Message', 'nothing to see here I am just a library required on setup')