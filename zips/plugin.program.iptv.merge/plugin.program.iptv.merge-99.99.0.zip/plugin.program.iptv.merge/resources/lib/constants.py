PLAYLIST_FILE_NAME  = 'playlist.m3u8'
EPG_FILE_NAME       = 'epg.xml'

IPTV_SIMPLE_ID      = 'pvr.freeviewnzandroid'
INTEGRATIONS_URL    = 'https://k.slyguy.xyz/.iptv_merge/data.json.gz'

METHOD_PLAYLIST     = 'playlist'
METHOD_EPG          = 'epg'
MERGE_SETTING_FILE  = '.iptv_merge'